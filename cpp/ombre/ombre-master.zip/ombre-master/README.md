# ombre
Replace dll already loaded in different process. These process and dll doesn't need to know anything about hot-patch mechanism. Everything is handled by `ombre`. Great help when application has high restart cost.

